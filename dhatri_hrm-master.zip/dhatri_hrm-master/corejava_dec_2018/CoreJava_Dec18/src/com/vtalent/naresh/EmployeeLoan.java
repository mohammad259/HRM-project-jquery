package com.vtalent.naresh;

class EmployeeLoan extends Exception{
	public String toString() {
		return "This Employ is Not Eligible for Loan";
	}
}
