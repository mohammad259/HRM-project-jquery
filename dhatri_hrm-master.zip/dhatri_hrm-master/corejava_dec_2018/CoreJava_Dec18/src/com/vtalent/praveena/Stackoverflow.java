package com.vtalent.praveena;

public class Stackoverflow 
{
 Stackoverflow abc=new Stackoverflow();
	int i;

public static void main(String[]args)
{
	Stackoverflow abc1=new Stackoverflow();
	abc1.i=10;
	System.out.println(abc1.i);
}

}
