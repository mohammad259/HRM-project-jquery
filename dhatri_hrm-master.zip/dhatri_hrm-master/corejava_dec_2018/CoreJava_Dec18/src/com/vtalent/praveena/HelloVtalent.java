package com.vtalent.praveena;

public class HelloVtalent {

	public static void main(String args[]) {

		System.out.println("hai");

	}
}