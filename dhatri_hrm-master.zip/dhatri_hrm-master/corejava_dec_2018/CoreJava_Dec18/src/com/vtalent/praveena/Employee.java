package com.vtalent.praveena;

public class Employee {
	private int employeeID;
	private double employeeSalary;
	public void setemployeeID(int employeeID)
	{
		this.employeeID=employeeID;
	}
	public void setemployeeSalary(double employeeSalary)
	{
		this.employeeSalary=employeeSalary;
	}
	public int getemployeeID()
	{
		return this.employeeID;
	}
	public double getemployeeSalary()
	{
		return this.employeeSalary;
	}
}
