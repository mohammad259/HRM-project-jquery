package com.vtalent.raju;

class EmployeeLoan extends Exception{
	public String toString() {
		return "This Employ is Not Eligible for Loan";
	}
}
 
	
	/*
	 * public void employLoan(double salary) { try { if(salary<20000) { throw new
	 * EmployLoan(); } else {
	 * System.out.println("This Employ is Eligible for Loan "); } } catch(EmployLoan
	 * e) { System.out.println(e); } }
	 */
	
	


