package com.vtalent.raju;

public class Minmax {

}
