package com.vtalent.raju;

public class Duplicate {
	  String str="rama";
		System.out.println(removeduplicate(str));
	
	
	public static string removeduplicate(string str) {
		set<character> set = new hashset<>();
		StringBuffer sf = new StringBuffer();
		
		
		
		
	}
	

}
