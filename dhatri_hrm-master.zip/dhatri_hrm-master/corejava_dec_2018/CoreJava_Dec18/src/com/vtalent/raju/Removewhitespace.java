package com.vtalent.raju;

public class Removewhitespace {

}
