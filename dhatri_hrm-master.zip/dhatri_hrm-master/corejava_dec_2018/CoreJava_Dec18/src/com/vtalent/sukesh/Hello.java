package com.vtalent.sukesh;

public class Hello {

}
