package com.vtalent.sukesh;

public class Prime {

}
