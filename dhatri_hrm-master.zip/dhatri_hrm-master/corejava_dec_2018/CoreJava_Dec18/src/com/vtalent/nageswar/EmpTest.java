package com.vtalent.nageswar;

public class EmpTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
