package com.vtalent.nageswar;

public class ExceptionEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
