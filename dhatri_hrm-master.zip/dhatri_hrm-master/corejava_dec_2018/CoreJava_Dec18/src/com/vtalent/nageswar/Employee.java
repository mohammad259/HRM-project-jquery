package com.vtalent.nageswar;

public class Employee {

	private int employeeID;

	private double employeeSalary;

	public void setEmployeeId(int employeeId) {
		this.employeeID = employeeId;
	}

	public void setEmployeeSalary(double employeeSalary) {
		this.employeeSalary = employeeSalary;
	}
	
	public int getEmployeeId() {
		return employeeID;
	}
	
	public double getEmployeeSalary() {
		return employeeSalary;
	}

	 
}