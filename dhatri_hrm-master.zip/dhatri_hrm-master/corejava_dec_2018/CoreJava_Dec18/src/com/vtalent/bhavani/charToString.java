package com.vtalent.bhavani;

public class charToString {

		


public static void main(String[] args) {
	char[] ch={'a','b','c','d'};
	String s=new String(ch);
	System.out.println(s);
}
}
