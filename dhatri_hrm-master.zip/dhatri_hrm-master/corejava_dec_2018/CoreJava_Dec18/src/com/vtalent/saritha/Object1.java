
	package com.vtalent.saritha;

	public class Object1 {
		Object1 o20=new Object1();
		int k;
		public void function(){
			System.out.println(k);
		}

		public static void main(String[] args) {
			// TODO Auto-generated method stub
			Object1 oe1=new Object1();
			oe1.k=10;
			//oe1.function();

		}

	}
