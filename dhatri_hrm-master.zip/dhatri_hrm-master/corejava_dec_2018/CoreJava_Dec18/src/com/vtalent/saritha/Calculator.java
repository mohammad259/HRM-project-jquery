package com.vtalent.saritha;

public class Calculator {

}
