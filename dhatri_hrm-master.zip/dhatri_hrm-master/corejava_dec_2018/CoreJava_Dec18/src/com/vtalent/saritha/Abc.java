package com.vtalent.saritha;

public class Abc {
	static Abc abc=new Abc();
	int i;
	public static void main(String []args){
		Abc abc1=new Abc();
		abc1.i=10;
		System.out.println(abc1.i);
		
	}

}
