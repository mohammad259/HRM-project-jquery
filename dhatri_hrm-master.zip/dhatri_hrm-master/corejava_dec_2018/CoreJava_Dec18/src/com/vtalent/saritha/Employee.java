package com.vtalent.saritha;
public class Employee{
	
private int employid;
private double employsalary;
private String mobileNumber;
private String employName;
private double employPackage;
private float pf;

public int getEmployid() {
	return employid;
}

public void setEmployid(int employid) {
	this.employid = employid;
}

public double getEmploysalary() {
	return employsalary;
}

public void setEmploysalary(double employsalary) {
	this.employsalary = employsalary;
}

public String getMobileNumber() {
	return mobileNumber;
}

public void setMobileNumber(String mobileNumber) {
	this.mobileNumber = mobileNumber;
}

public String getEmployName() {
	return employName;
}

public void setEmployName(String employName) {
	this.employName = employName;
}

public double getEmployPackage() {
	return employPackage;
}

public void setEmployPackage(double employPackage) {
	this.employPackage = employPackage;
}

public float getPf() {
	return pf;
}

public void setPf(float pf) {
	this.pf = pf;
}

}
