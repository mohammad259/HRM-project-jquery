package com.vtalent.saritha;

public class First {
	int i,j;
	public void function(int i){
		this.i=this.i+i;
		j=this.j+j;
	}
}
		