package com.vtalent.saritha;

class HelloWorld {

	public HelloWorld() {
		// TODO Auto-generated constructor stub
	}

}
