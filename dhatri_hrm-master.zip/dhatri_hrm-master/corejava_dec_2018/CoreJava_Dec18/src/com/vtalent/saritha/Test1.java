package com.vtalent.saritha;



public class Test1 {
	
		public static void main(String[] args){
			Demoo1 demo3=new Demoo1();
			demo3.function1(5);
			demo3.function2(5,5);
			System.out.println(demo3.x);
			System.out.println(demo3.y);
			Demo2 demoo1=new Demo2();
        	/*demoo1.function1(5);
			demoo1.function2(5,5);
			System.out.println(demoo1.x);
			System.out.println(demoo1.y);
		}*/
}
}
