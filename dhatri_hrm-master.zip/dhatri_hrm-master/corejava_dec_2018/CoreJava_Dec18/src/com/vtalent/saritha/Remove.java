package com.vtalent.saritha;

import java.util.Scanner;

public class Remove {
 

		public static void main(String[] args) {
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter first String");
			String s1=sc.nextLine();
			System.out.println(s1.replace(" ", ""));

		}

	}

