package com.vtalent.saritha;

public class Second extends First{
	int j;
	public void function(int j,int i){
		super.j=super.j+this.j;
		this.i=this.i+i;
	}

}
