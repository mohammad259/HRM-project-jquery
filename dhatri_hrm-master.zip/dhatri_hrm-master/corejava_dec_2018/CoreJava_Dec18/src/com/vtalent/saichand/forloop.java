package com.vtalent.saichand;

public class forloop {
	public static void main(String args[]) {
		for (int i = 10; i >= 1; i--) 
			System.out.println("The value of i is: " + i);
		
	}

}
