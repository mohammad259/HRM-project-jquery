package com.vtalent.saichand;

public class object20 {
	static object20 o20 = new object20();
	int k;

	public void function() {
		System.out.println(k);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		object20 oe1 = new object20();
		oe1.k = 10;
		// oe1.function();

	}

}
