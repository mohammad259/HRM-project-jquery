package com.vtalent.saichand;

public class nestedForLoop2 {
	public static void main(String args[]) {
		for (int i = 10; i > 1; i--) {
			for (int j = 10; j > 1; j--) {
				System.out.println("The value of i is: " + i);
				System.out.println("The value of j is: " + j);
			}
		}
	}

}
