package com.vtalent.mahadev;

public class hello {

}
