package com.vtalent.mahadev;

public class Abck {
	Abck abc=new Abck();
	int i;
	public static void main(String[] args) {
		Abck abc1=new Abck();
		abc1 i=10;
		System.out.println(abc1.i);
	}

}
