package com.vtalent.mahadev;

public class EmployeecustomException extends Exception  {
	public String toString() {
		return "You are Not Eligible for Loans Why Becouse you  are Salary is Very low";
	}

}
