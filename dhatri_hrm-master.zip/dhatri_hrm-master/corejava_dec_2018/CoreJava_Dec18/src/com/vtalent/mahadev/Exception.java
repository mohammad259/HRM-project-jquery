package com.vtalent.mahadev;

public class Exception {
	int[] array=new int[4];
	String str;
	public void function(){
	//	int i=1/array[0];
	//	char ch=str.charAt(0);
		//array[4]=7;
	}
public static void main(String[] args) {
	Exception ee=new Exception();
	ee.function();
}
}
