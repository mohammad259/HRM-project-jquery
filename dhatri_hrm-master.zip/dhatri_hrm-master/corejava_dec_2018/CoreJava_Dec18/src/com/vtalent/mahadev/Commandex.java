package com.vtalent.mahadev;

public class Commandex {
	
	public static void main(String[] args) {
		
		for(int i = 0;i<=args.length-1;i++){
			System.out.println(args[i]);
		}
	}

}
