package com.vtalent.vittalharish;

public class Employee {

	private int employeeID;

	private double employeeSalary;
	
	private String employeeName;
	
	private Double employeePackage;
	
	private Double employeePF;
	
	private String empolyeeMobileNumber;

	public String getEmpolyeeMobileNumber() {
		return empolyeeMobileNumber;
	}

	public void setEmpolyeeMobileNumber(String empolyeeMobileNumber) {
		this.empolyeeMobileNumber = empolyeeMobileNumber;
	}

	public int getEmployeeID() {
		return employeeID;
	}

	public void setEmployeeID(int employeeID) {
		this.employeeID = employeeID;
	}

	public double getEmployeeSalary() {
		return employeeSalary;
	}

	public void setEmployeeSalary(double employeeSalary) {
		this.employeeSalary = employeeSalary;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public Double getEmployeePackage() {
		return employeePackage;
	}

	public void setEmployeePackage(Double employeePackage) {
		this.employeePackage = employeePackage;
	}

	public Double getEmployeePF() {
		return employeePF;
	}

	public void setEmployeePF(Double employeePF) {
		this.employeePF = employeePF;
	}
	

	
}