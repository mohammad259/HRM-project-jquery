package com.vtalent.vittalharish;

 class EmployeeCustomLoanException extends Exception  {

	  public String toString() {
		  
		return "You Are Not Eligible For Loan. Kindly Check Your Details Again ";
		  
	  }
}
