package com.vtalent.rakesh;

public class MultipleInheritance implements One, Two {

	public void qwerty() {

	}

}
