package com.vtalent.rakesh;

public abstract class CalculatorOne extends AbstractionCalculator {

}
