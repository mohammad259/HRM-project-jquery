package com.vtalent.rakesh;

public 	class DemoOne {
		int x, y;

		public void function(int x) {

			this.x = x + this.x;
			y = x + y;
		}

		public void function(int x, int y) {
			this.x = this.x + x;
			this.y = this.y + x;
		}
	}

	
	
