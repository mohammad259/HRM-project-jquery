package com.vtalent.rakesh;

public class GetALoanException extends Exception {

	public String toString() {
		return "salary should be grater than 25,000.not eligible for loan";

	}
}
