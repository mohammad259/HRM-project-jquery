package com.vtalent.rakesh;

public abstract class AbstractionCalculator {

	public double add(double x, double y) {

		double z;
		return z = (x + y);
	}

	public abstract String addStrings(String q, String w);

}