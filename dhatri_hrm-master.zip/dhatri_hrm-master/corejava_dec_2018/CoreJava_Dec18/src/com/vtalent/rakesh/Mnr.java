package com.vtalent.rakesh;

public interface Mnr extends Abc, Xyz {

}
