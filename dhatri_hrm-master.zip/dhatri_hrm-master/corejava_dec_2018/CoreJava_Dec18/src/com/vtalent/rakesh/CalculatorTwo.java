package com.vtalent.rakesh;

public class CalculatorTwo extends CalculatorOne {

	public String addStrings(String q, String w) {
		String z = q + w;

		return z;
	}

}
