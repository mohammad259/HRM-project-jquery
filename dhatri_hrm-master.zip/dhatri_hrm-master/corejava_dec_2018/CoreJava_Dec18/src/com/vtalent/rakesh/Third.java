package com.vtalent.rakesh;

public class Third extends Second {
	public int function(int i, int j, int k) {
		int l;
		return (l = i * j * k);
	}

}
