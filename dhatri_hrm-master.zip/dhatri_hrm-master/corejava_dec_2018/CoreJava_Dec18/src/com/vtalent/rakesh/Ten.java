package com.vtalent.rakesh;

public class Ten extends ReturnType {

	int k;

	public void qwerty() {
		int z = this.k;
	}

}
