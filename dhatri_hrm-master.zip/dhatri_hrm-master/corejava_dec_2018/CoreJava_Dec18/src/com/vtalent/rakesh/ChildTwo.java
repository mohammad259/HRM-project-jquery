package com.vtalent.rakesh;

public class ChildTwo extends ChildOne {
	public void function() {
		System.out.println("method in childTwo");
	}

}
