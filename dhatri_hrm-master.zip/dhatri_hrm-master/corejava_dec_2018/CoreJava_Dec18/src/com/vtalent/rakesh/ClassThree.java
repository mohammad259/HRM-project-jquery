package com.vtalent.rakesh;

public class ClassThree extends ClassTwo{

}
