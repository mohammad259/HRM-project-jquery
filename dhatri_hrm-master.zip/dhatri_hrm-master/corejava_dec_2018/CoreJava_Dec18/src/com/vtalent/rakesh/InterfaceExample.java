package com.vtalent.rakesh;

public interface InterfaceExample {
	public int function(float f1);

	public float function(int x, int y);

}
