package com.vtalent.rakesh;

public class ClassTwo extends MultilevelInheritanceClassOne {

	public void function() {
		System.out.println("ClassTwo");
	}
}
