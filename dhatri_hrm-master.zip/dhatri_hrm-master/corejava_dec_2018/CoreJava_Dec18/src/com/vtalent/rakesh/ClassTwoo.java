package com.vtalent.rakesh;

public class ClassTwoo extends ClassOne {

	public int function(double d, int h, int j) {

		return h;
	}
}
