package com.vtalent.rakesh;

public interface Two {
	public void qwerty();
}
