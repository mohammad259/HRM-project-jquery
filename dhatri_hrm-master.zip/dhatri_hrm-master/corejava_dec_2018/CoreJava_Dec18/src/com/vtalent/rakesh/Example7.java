package com.vtalent.rakesh;

import java.io.IOException;

class Example7 {
	public float Twin(float x, float y) throws IOException {
		return 0;
	}
}

class SubExample7 extends Example7 {
	public float Twin(float x, float y) {
		return 0;
	}
}
