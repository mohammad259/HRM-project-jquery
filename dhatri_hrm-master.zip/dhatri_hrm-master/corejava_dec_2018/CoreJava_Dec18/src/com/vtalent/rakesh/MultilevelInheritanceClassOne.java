package com.vtalent.rakesh;

public class MultilevelInheritanceClassOne {
	public void function() {
		System.out.println("ClassOne");

	}

	public static void main(String args[]) {
		ClassThree q = new ClassThree();
		q.function();
	}
}
