package com.vtalent.rakesh;

public class DemoTwo extends DemoOne {

	int x;

	public void function(int x) {
		this.x = this.x + x;
	}
}