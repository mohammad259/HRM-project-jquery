package com.vtalent.rakesh;

public class ChildOne extends Parent {
	public void function() {
		System.out.println("method in ChildOne");
	}
}
