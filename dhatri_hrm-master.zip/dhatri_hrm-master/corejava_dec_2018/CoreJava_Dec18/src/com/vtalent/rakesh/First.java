package com.vtalent.rakesh;

public class First {
	int i, j;

	public int function(int i) {
		this.i = this.i + i;
		j = this.j + j;
		return i;
	}

}
