package com.vtalent.rakesh;

public interface One {
	public void qwerty();
}
