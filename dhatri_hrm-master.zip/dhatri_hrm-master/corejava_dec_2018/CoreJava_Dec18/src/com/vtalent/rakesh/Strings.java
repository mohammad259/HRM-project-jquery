package com.vtalent.rakesh;

import java.util.Scanner;

public class Strings {
	public static void main(String[] args) {
		try {
			System.out.println("enter");
			Scanner c = new Scanner(System.in);
			String s = c.next();
			System.out.println(s);
			String q = s + "uihgr";
			int[] arrry = { 1, 2, 3, 4 };
			int[] arryyy = null;
			System.out.println("hi");
			for (int i = 0; i <= arryyy.length - 1; i++) {
				System.out.print(arrry[i]);

			}
		} catch (Exception e) {
		}
	}
}
