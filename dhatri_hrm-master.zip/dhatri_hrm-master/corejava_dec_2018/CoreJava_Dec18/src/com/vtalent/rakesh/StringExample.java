package com.vtalent.rakesh;

public class StringExample {
	public static void main(String args[]) {

		String s1 = new String();
		String s2 = new String("abc");

		if (s1.equals(s2)) {
			System.out.println(s2);
		} else {
			System.out.println(s2);
		}
		String s3 = "rakesh";
		String s4 = "rakesh";
		if (s3 == s4) {
			System.out.println(s3);
		}
		// System.out.println(s4);

	}

}
