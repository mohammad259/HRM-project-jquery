package com.vtalent.rakesh;

public class MethodInMainMethod {

	public void qwe() {

	}

	public static void main(String[] args) {

	}
}
