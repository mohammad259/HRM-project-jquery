package com.vtalent.rakesh;

public interface Xyz {

	public void function();
}
