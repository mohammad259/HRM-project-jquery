package com.vtalent.rakesh;

public interface Abc {
	// int i;
	float p = 3.14f;
	int k = 0;

	void function(int x, int y);
}
