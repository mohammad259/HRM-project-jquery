package com.vtalent.rakesh;

public class Fourth extends Third {
	public int function(int m) {

		return m;
	}
}
