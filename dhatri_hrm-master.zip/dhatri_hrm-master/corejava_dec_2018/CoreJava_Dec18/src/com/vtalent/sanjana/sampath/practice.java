package com.vtalent.sampath;

public class practice {

	private String fmovie;


	public String getFmovie() {
		return fmovie;
	}

	public void setFmovie(String fmovie) {
		this.fmovie = fmovie;
	}
	
}
