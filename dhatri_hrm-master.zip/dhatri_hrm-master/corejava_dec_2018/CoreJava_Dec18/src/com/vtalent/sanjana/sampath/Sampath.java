package com.vtalent.sampath;
import java.util.Scanner;
public  class Sampath{
	public static void main(String[] args) {
		int x,y,z;
		System.out.println("Enter two integers");
		Scanner Sc= new Scanner(System.in);
		x=Sc.nextInt();
		y=Sc.nextInt();
		z=x+y;
		System.out.println("Total Value:"+z);
		
		
		
		
		
				
	}
	
}