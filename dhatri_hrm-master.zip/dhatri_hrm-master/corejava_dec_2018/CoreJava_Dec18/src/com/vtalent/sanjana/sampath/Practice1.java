package com.vtalent.sampath;



public class Practice1 {
	public static void main (String args[])
	{
		practice obj=new practice();
		obj.getFmovie();
		
		
		
	}

}
