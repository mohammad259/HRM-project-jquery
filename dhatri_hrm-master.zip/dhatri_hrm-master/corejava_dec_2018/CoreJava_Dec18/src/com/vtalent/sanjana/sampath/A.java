package com.vtalent.sampath;

public class A {
private float f1;
private A(){
	f1=2.5f;
	
	
}
public static A function() {
	A al=new A();
	return al;
	
}
public float getvalue() {
	return f1;
}
}
	