package com.vtalent.sanjana;

public class Abc {

int i;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Abc abc1=new Abc();
abc1.i=10;
System.out.println(abc1.i);
	}

}
