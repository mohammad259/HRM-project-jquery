package com.vtalent.sampath;

public class EncapsulationDemo2 {
	public static void main(String args[]) {
	EncapsulationDemo ed=new EncapsulationDemo();
	ed.setName("sampath");
	System.out.println(ed.getName());
	
		
	}

}
