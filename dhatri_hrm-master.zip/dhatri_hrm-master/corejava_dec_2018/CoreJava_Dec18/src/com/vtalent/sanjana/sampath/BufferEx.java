package com.vtalent.sampath;

public class BufferEx {
	public static void main(String[] args) {
		
	}

}
