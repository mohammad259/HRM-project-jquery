package com.vtalent.sanjana;


public class Object20 {
	static Object20 o20=new Object20();
	int k;
	public void function(){
		System.out.println(k);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Object20 oe1=new Object20();
		oe1.k=10;
		oe1.function();

	}

}
