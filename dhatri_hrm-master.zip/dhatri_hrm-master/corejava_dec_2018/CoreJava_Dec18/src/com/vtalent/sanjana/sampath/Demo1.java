package com.vtalent.sampath;
/**
 */**
 * @author ABHI
public class Demo1 {
	 int i,j;
	 
	                    static float f1,f2; 
	                    
	                    public void function_one() { 
	                    					i=5; j=7; 
	                    					}
	 
	public static int function_two(float f1) {
		Demo1 f1=f1+Demo1.f1;
		f2=Demo1.f1+f1;
		return (int)f1;
	}
	public static void main(String args[]) {
		Demo1.dem=new Demo();
		dem.function_one();
		int k=function two ((float)demo i);
		System.out.println(k);
		System.out.println(demo.i+demo.j);
		System.out.println(f1+f2);
		
		
		
	}

}
