package com.vtalent.sampath;
import java.util.Scanner;
public class Ifelse {
	public static void main(String[] args) {
		int passed,Marksobtained;
		System.out.println("Enter the marks");
		Scanner Sc=new Scanner(System.in);
		passed=40;
		Marksobtained=Sc.nextInt();
		
		if(passed<=Marksobtained) {
		System.out.println("passed");
		
	}
	else {
		System.out.println("failed");
	}
	
	
	

	}}
