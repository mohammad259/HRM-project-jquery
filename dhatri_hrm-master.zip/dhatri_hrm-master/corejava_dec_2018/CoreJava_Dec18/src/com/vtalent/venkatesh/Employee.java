package com.vtalent.venkatesh;

public class Employee {
     private int employid;
	private double employsalary;
	
	public void setEmployId(int employid) 
	{
		this.employid=employid;
	}
	
	public void setEmploySalary(double employsalary)
	{
		this.employsalary=employsalary;
	}
	
	public int getEmployId()
	{
		return employid;
	}
		public double getEmploySalary() 
	{
			return employsalary;
		}
}

