package com.vtalent.venkatesh;

public class Poly3 extends Poly2 {
     Poly3() {
	  super();
     }
  
     public long function(long l1) {
	  l1 = super.function(l1);
	  this.l1 = this.l1 + l1;
	  return l1;
     }

}
