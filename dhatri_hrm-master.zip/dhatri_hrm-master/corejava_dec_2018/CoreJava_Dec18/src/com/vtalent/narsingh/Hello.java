package com.vtalent.narsingh;

public class Hello {

}
