package com.vtalent.narsingh;

import java.util.Scanner;

/**
 * 
 * @author TOSHIBA
 *
 */
public class mohammad {
	

}
