package com.vtalent.kirankumar;

public class PullMethod {

}
