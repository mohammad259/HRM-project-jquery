package com.vtalent.kirankumar;

public class PushMethod {

}
