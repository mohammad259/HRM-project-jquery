package com.vtalent.kirankumar;

public class EmployeeLoan extends Exception{
	public String toString() {
		return "This Employee is Not Eligible for Loan";
	}
}
