package com.vtalent.kirankumar;

public class ParentClasss {
public static void main(String[] args) {
	System.out.println("hey welcome");
}
}
