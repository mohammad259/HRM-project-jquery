package com.vtalent.mahadev1;

public class Employee {
 private int EmployeeId;
 private double EmployeeSalary;
public int getEmployeeId() {
	return  this.EmployeeId;
}
public void setEmployeeId(int employeeId) {
	this.EmployeeId = employeeId;
}
public double getEmployeeSalary() {
	return this.EmployeeSalary;
}
public void setEmployeeSalary(double employeeSalary) {
	this.EmployeeSalary = employeeSalary;
}
 
 
}
