package com.vtalent.srihari;

@SuppressWarnings("serial")
public class EmployeeCustomException extends Exception {

	public String toString() {
		return "You are Not Eligible for Loans Why Becouse you  are Salary is Very low";
	}
}
