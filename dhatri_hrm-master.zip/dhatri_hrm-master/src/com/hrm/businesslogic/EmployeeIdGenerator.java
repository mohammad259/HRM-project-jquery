package com.hrm.businesslogic;

import java.text.DecimalFormat;
import java.util.Random;

public class EmployeeIdGenerator
{
	
	private static Random random=new Random();
	
	public static String getEmployeeId()
	{
		String employeeId="";
		employeeId="DS-"+unqiueNo();
		return employeeId;
	}
	
	private static final String unqiueNo()
	{	StringBuilder bld=new StringBuilder();
		String fourDigits="";
		String temp=""+factorial();
		if(temp.length()>4)
		{
			for(int i=0;i<=4;i++)
				bld=bld.append(temp.charAt(i));
				fourDigits=bld.toString();
		}
		else
		{
			
			DecimalFormat df = new DecimalFormat("00000");
			int number=Integer.parseInt(temp);
			
			 fourDigits=df.format(number);
			
		}
		
		
		return fourDigits;
		
	}
	
	private static int factorial()
	{
		int fact=1;
		
		int randomNo=random.nextInt(20);
		for(int i=1;i<randomNo;i++)
		{
			fact=fact*i;
		}
		
		return fact;
	}
	public static void main(String[] args) {
		System.out.println(getEmployeeId());
	}

}
